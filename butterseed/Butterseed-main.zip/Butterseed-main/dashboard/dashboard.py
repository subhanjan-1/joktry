# app.py

from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('dashboard/dashboard.html')

@app.route('/update_activity', methods=['POST'])
def update_activity():
    activity = request.form.get('activity')
    frequency = request.form.get('frequency')
    # TODO: Handle the submitted data (e.g., store it in a database)
    return f"Activity updated: {activity}, Frequency: {frequency}"

if __name__ == '__main__':
    app.run(debug=True)
