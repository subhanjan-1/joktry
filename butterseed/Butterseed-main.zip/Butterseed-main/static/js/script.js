document.addEventListener("DOMContentLoaded", function () {
    var navbar = document.getElementById('navbar');
    var isNavbarVisible = true;

    window.addEventListener('scroll', function () {
        var scrollPosition = window.scrollY;

        // Toggle the background color of the navbar based on scroll position
        if (scrollPosition > 0 && isNavbarVisible) {
            navbar.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
        } else {
            navbar.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
        }

        // Toggle the visibility of the navbar based on scroll position
        if (scrollPosition > 100 && isNavbarVisible) {
            navbar.style.opacity = 0;
            isNavbarVisible = false;
        } else if (scrollPosition <= 100 && !isNavbarVisible) {
            navbar.style.opacity = 1;
            isNavbarVisible = true;
        }
    });

    var stages = document.querySelectorAll('.stage');

    stages.forEach(function (stage) {
        stage.addEventListener('click', function (event) {
            var infoBox = stage.querySelector('.info-box');
            infoBox.style.display = 'block';

            // Add a click event listener to close the info box when clicking outside
            document.addEventListener('click', closeInfoBoxOutside);

            function closeInfoBoxOutside(e) {
                if (!infoBox.contains(e.target) && e.target !== stage) {
                    infoBox.style.display = 'none';
                    document.removeEventListener('click', closeInfoBoxOutside);
                }
            }
        });
    });

    // Initialize WOW.js
    new WOW().init();

    // Add your additional script here...

   
});

$(document).ready(function () {
    var options = {
        strings: ["Startup.", "Entreprenuer.", "Innovator."],
        typeSpeed: 30,
        startDelay: 1200,
        backSpeed: 20,
        backDelay: 500,
        loop: true,
        loopCount: 5,
        showCursor: false,
        cursorChar: "|",
        attr: null,
        contentType: 'html',
        callback: function () {},
        preStringTyped: function () {},
        onStringTyped: function () {},
        resetCallback: function () {}
    };

    var typed = new Typed('.typed', options);
});

// Add your additional script here...
