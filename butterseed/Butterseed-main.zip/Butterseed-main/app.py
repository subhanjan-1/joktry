from flask import Flask, render_template, request, redirect, url_for, send_file
from flask_pymongo import PyMongo
from flask import flash
import os
import re
import secrets
from werkzeug.security import generate_password_hash
from werkzeug.utils import secure_filename
from io import BytesIO
from gridfs import GridFS
from pptx import Presentation
from io import BytesIO
from werkzeug.security import check_password_hash
from flask import session
from datetime import datetime
from flask_wtf.csrf import generate_csrf
from flask import jsonify





app = Flask(__name__)

# Configure the Flask application to use MongoDB Atlas
app.config["MONGO_URI"] = "mongodb://localhost:27017/butterseed"

# for uploading file
app.config["SECRET_KEY"] = "your_secret_key_here"  # Set a secret key for flashing messages
app.config["UPLOADED_FILES_DEST"] = "uploads"  # Destination folder for uploaded files

mongo = PyMongo(app)
# Set the upload folder
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Set the local directory for synchronization
LOCAL_SYNC_DIR = 'synced_files'
if not os.path.exists(LOCAL_SYNC_DIR):
    os.makedirs(LOCAL_SYNC_DIR)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/redirect_login', methods=['GET', 'POST'])
def redirect_login():
    return render_template('login.html')

def authenticate_user(username, password):
    # Query the MongoDB collection to find a user with the provided username
    user = mongo.db.user.find_one({'email': username})
    
    # Check if a user with the provided username exists
    if user:
        # Compare the hashed password stored in the database with the provided password
        if check_password_hash(user['password'], password):
            # If passwords match, return True (authentication successful)
            return True
    # If user does not exist or password does not match, return False
    return False


@app.route('/startup_login', methods=['GET', 'POST'])
def startup_login():
        if request.method == 'POST':
            # Process the form data
            username = request.form.get('email')
            password = request.form.get('password')
        
        # Authenticate the user
        if authenticate_user(username, password):
            # If authentication is successful, store username in session
            session['username'] = username
            # Redirect to the next HTML page (e.g., slide.html)
            return redirect(url_for('upload'))
        else:
            # If authentication fails, render login.html with an error message
            flash('Invalid username or password', 'error')
            return render_template('login.html', error=True)

@app.route('/startup_signup', methods=['GET', 'POST'])
def startup_signup():
    # Add your login logic here
    # For example, you might process the form data and authenticate the user
    
    # Once authentication is done, render the login.html template
    return render_template('signup.html')

# @app.route('/login', methods=['POST'])
# def login():
#     if request.method == 'POST':
#         # Get form data for login
#         email = request.form['email']
#         password = request.form['password']

#         # Check if user exists in the database
#         user = mongo.db.user.find_one({'email': email, 'password': password})
#         if user:
#             # If user exists, redirect to a success page or perform other actions
#             return redirect(url_for('login_success'))
#         else:
#             # If user does not exist, redirect back to the login page or display an error message
#             return redirect(url_for('startup_login'))


# Generate a random secret key
app.secret_key = secrets.token_hex(16)  # Generates a 32-character random hexadecimal string

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # Get form data for signup
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        # Check if the email already exists in the database
        existing_user = mongo.db.user.find_one({'email': email})
        if existing_user:
            # If email already exists, show a message and ask the user to log in instead
            flash('Email already exists. Please login instead.', 'error')
            # message = "Email already exists. Please login instead."
            # return redirect(url_for('startup_login'))
            return render_template('login.html', error=True)  # Pass error flag to the template

        # # Set rules for password
        # if not re.match(r'^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()-_+=])[A-Za-z0-9!@#$%^&*()-_+=]{8,}$', password):
        #     flash('Password should contain at least 1 capital letter, 1 special character, 1 number, and be 8 characters long.', 'error')
        #     return redirect(url_for('signup'))

        # Hash the password before storing it in the database
        hashed_password = generate_password_hash(password)

        # Insert the user data into the database
        mongo.db.user.insert_one({'name': name, 'email': email, 'password': hashed_password})

        # Log the data being posted
        print("Name:", name)
        print("Email:", email)
        print("Password:", hashed_password)

        # Redirect the user to a success page
        return redirect(url_for('signup_success'))

    # If the request method is not POST, redirect to the signup form
    return redirect(url_for('signup'))


# @app.route('/login_success')
# def login_success():
#     return render_template('login_success.html')

@app.route('/signup_success')
def signup_success():
    return render_template('signup_success.html')

# @app.route('/upload', methods=['POST'])
# def upload():
#     if request.method == 'POST':
#         file = request.files['file']

#         mongo.db.upload.insert_one({'filename': file.filename, 'data': file.read()})

#         return f'Uploaded: {file.filename}'
#     return render_template('slide.html')

def sync_file_with_local(filename, file_binary_data):
    # Write or overwrite the file in the local directory
    with open(os.path.join(LOCAL_SYNC_DIR, filename), 'wb') as file:
        file.write(file_binary_data)

@app.route('/upload', methods=['POST'])
# def upload():
#     if request.method == 'POST':
#         # Check if the post request has the file part
#         if 'file' not in request.files:
#             flash('No file part')
#             return redirect(request.url)
        
#         file = request.files['file']
        
#         # If user does not select file, browser also
#         # submit an empty part without filename
#         if file.filename == '':
#             flash('No selected file')
#             return redirect(request.url)

#         if file:
#             filename = secure_filename(file.filename)
#             file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            
#             # Save the file into MongoDB
#             file_binary_data = file.read()
#             mongo.db.files.insert_one({'filename': filename, 'binary_data': file_binary_data})
            
#             # Synchronize the file with the local directory
#             sync_file_with_local(filename, file_binary_data)
            
#             flash('File uploaded successfully', 'success')
#             return redirect(url_for('index'))

# def upload():
#     if request.method == 'POST':
#         file = request.files['file']
        
#         if file:
#             try:
#                 # Insert file data into MongoDB
#                 mongo.db.upload.insert_one({'filename': file.filename, 'data': file.read()})
#                  # Save the file into MongoDB using GridFS
#                 mongo.save_file(file.filename, file)
#                 print(f"Uploaded file: {file.filename}")  # Debug statement
#                 return f'Uploaded: {file.filename}'
#             except Exception as e:
#                 # Log any errors
#                 print(f"Error uploading file: {e}")
#                 return "An error occurred while uploading the file"
#         else:
#             return "No file selected for upload"
    
#     return render_template('slide.html')


# def upload():
#     if request.method == 'POST':
#         file = request.files['file']
        
#         if file:
#             try:
#                 # Read the uploaded PowerPoint file
#                 presentation_data = file.read()
                
#                 # Create a BytesIO object to read the file
#                 presentation_stream = BytesIO(presentation_data)
                
#                 # Create a PowerPoint presentation object
#                 presentation = Presentation(presentation_stream)
                
#                 # Extract text from each slide
#                 slides_text = []
#                 for slide in presentation.slides:
#                     slide_text = ''
#                     for shape in slide.shapes:
#                         if hasattr(shape, 'text'):
#                             slide_text += shape.text + '\n'
#                     slides_text.append(slide_text.strip())
                
#                 # Insert the extracted text into MongoDB
#                 mongo.db.upload.insert_one({
#                     'filename': file.filename,
#                     'slides_text': slides_text
#                 })
                
#                 print(f"Uploaded file: {file.filename}")  # Debug statement
#                 return f'Uploaded: {file.filename}'
#             except Exception as e:
#                 # Log any errors
#                 print(f"Error uploading file: {e}")
#                 return "An error occurred while uploading the file"
#         else:
#             return "No file selected for upload"
    
#     return render_template('slide.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    username = session.get('username')
    print(username)
    if not username:
        return redirect(url_for('redirect_login'))  # Redirect to login if user is not logged in
    file_data = mongo.db.upload.find_one({'username': username})
    
    # Fetch the filename associated with the username
    file_data = mongo.db.upload.find_one({'username': username})
    fileName = None
    if file_data:
            fileName = file_data.get('filename')  # Set fileName if file data found
            # file_data = file_data.get('file_data')
            # return send_file(BytesIO(file_data), as_attachment=True, download_name=fileName)

    
    if request.method == 'POST':
        file = request.files['file']
        
        if file:
            try:
                # Read the uploaded PowerPoint file
                presentation_data = file.read()
                
                # Create a BytesIO object to read the file
                presentation_stream = BytesIO(presentation_data)
                
                # Create a PowerPoint presentation object
                presentation = Presentation(presentation_stream)
                
                # Extract text from each slide
                slides_text = []
                for slide in presentation.slides:
                    slide_text = ''
                    for shape in slide.shapes:
                        if hasattr(shape, 'text'):
                            slide_text += shape.text + '\n'
                    slides_text.append(slide_text.strip())
                
                # Find existing file data associated with the user
                existing_file_data = mongo.db.upload.find_one({'username': username})
            
                if existing_file_data:
                    # If an existing file is found, update its data
                    mongo.db.upload.update_one({'_id': existing_file_data['_id']}, {
                    '$set': {
                        'filename': file.filename,
                        'file_data': presentation_data,
                        'slides_text': slides_text
                    }
                    })
                    print(f"Updated file '{file.filename}' for user '{username}'")
                else:
                    # If no existing file is found, insert a new document
                    mongo.db.upload.insert_one({
                        'username': username,
                        'filename': file.filename,
                        'file_data': presentation_data,
                        'slides_text': slides_text
                    })
                    print(f"Uploaded file '{file.filename}' for user '{username}'")
              
                return redirect(url_for('upload'))  # Redirect to the same page after upload
            except Exception as e:
                print(f"Error uploading file: {e}")
                return "An error occurred while uploading the file"
        else:
            return "No file selected for upload"
    

    
    return render_template('slide.html', fileName=fileName)



@app.route('/download')
def download_user_file():
    fileName = None  # Initialize fileName variable
    
    if 'username' in session:
        username = session['username']
        file_data = mongo.db.upload.find_one({'username': username})
      
        if file_data:
            fileName = file_data.get('filename')  # Set fileName if file data found
            file_data = file_data.get('file_data')
            return send_file(BytesIO(file_data), as_attachment=True, download_name=fileName)
        
    # Pass fileName to the template
    # print(fileName)        
    return render_template('slide.html', fileName=fileName)

@app.route('/activity', methods=['GET', 'POST'])
def activity():
    csrf_token = generate_csrf()
    return render_template('activity.html', csrf_token=csrf_token)
    # return render_template('activity.html')

@app.route('/add_entry', methods=['POST'])
def add_entry():
    if request.method == 'POST':
        if 'username' in session:
            username = session['username']
            entry_title = request.form['entry-title']
            daily_entry = request.form['daily-entry']
            entry_date = datetime.now()

            # Insert the entry into the MongoDB collection along with the username
            mongo.db.entries.insert_one({
                'username': username,
                'title': entry_title,
                'entry': daily_entry,
                'date': entry_date
            })
            # Generate CSRF token
            csrf_token = generate_csrf()
            return render_template('activity.html', csrf_token=csrf_token)
        else:
            return 'User not logged in'
    else:
        return redirect(url_for('activity'))

@app.route('/get_entries', methods=['GET'])
def get_entries():
    if 'username' in session:
        username = session['username']
        # Query the MongoDB collection to fetch historical entries for the logged-in user
        entries = list(mongo.db.entries.find({'username': username}, {'_id': 0}))
        return jsonify({'entries': entries})
    else:
        return jsonify({'error': 'User not logged in'})
    

@app.route('/startup_dashboard', methods=['GET', 'POST'])
def startup_dashboard():
    if 'username' in session:
        username = session['username']
        user_data = mongo.db.user.find_one({'username': username})
        if user_data:
            name = user_data.get('name')
            return render_template('startup.html', name=name)
    return redirect(url_for('redirect_login'))



if __name__ == '__main__':
    app.run(debug=True)
